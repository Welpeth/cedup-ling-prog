package pacote2;

import pacote1.ClassePublica;
// import pacote1.ClassePrivada;

public class ClasseOutroPacote {
   ClassePublica obj1;
  // ClassePrivada obj2;
}
