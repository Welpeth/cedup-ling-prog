package pacote1;

/**
 *
 * @author Henri
 */
public class ClassePublica {
    int atributo1;
}
