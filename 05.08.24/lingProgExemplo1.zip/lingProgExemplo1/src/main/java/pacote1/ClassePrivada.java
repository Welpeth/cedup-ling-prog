package pacote1;

/**
 *
 * @author Henri
 */
class ClassePrivada {
    int atributo1;
}
