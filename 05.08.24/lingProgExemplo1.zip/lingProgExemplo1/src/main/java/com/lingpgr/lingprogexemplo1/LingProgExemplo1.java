package com.lingpgr.lingprogexemplo1;

/**
 *
 * @author Henri
 */
public class LingProgExemplo1 {
    
  /*  public static void main(String[] args) {
        System.out.println("Hello World!");
    } */
}
