package Exemplo;

public class ExecutarConta {
    public static void main(String[] args) {
        // Definindo o objeto na variável "objConta1" e instanciando-o na memória (Carregando na memória RAM).
        Conta objConta1  = new Conta();
        
        // Acessando os atributos e metodos com a variável "objConta1", através do conector "."
        objConta1.nome_titular = "Henrique";
        objConta1.numero = 100;
        
        // Fazendo um depósito
        objConta1.depositar(10100);
        System.out.println("Conta: " + objConta1.numero);
        System.out.println("Titular: " + objConta1.nome_titular);
        System.out.println("Saldo: " + objConta1.vlrSaldo);
    }
}
