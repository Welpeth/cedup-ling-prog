package Exemplo;

/**
 *
 * @author Henri
 */
public class Conta {
// Criando os atributos da Classe Conta.
    int numero;
    String nome_titular;
    double vlrSaldo;
    
// Criando o método depositar que recebe com parâmetro valor do depósito.
    void depositar(double valorDeposito) {
        this.vlrSaldo = this.vlrSaldo + valorDeposito;
    }
}
